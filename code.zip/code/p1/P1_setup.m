%% Simplified PUMA class statics
% run this file before running

clear

la=1;
lb=0.2;
lc=1;

%external force and moment at the tip (world frame)
external_force=[0;0;-1];
external_moment=[0;1;0];

%joint torque setting
tau1=0;
tau2=0;
tau3=0;

tf=3; % simulation end time

%% Generate path
radius = 0.1;
origin1 = [0.1, 0];
origin2 = [0.3, 0];
origin3 = [0.5, 0];
samples_per_segment = 1000;
path = generate_p1_path(radius, origin1, origin2, origin3, samples_per_segment);
% path = generate_test_path(radius, origin1, samples_per_segment);
path_size = size(path);
N = path_size(1); % Number of points

tt=tf/N:tf/N:tf;
%end point data for simscape
xed = path(:,1);
yed = path(:,2) + 0.5;
xedyedzedsim=[tt' xed yed zeros(length(tt),1)];

%initial angles
% Use IK to predict initial angle of timestep 0
position = [xed(1); yed(1); 0];
theta = InverseKinematics(position);
theta1 = theta(1);
theta2 = theta(2);
theta3 = theta(3);

%% Set gains
% ka = 0;
% kv = 60
% kp = 13000
% ki = 130

%% Forward Kinematics
% x = cos(theta1) * (la * cos(theta2) + lc * cos(theta2 + theta3))
% y = sin(theta1) * (la * cos(theta1) + lc * cos(theta2 + theta3))
% z = la * sin(theta1) + lc * sin(theta2 + theta3)

% %% Jacobian
% J = [
%     -sin(theta1) * (la * cos(theta2) + lc * cos(theta2 + theta3)), -cos(theta1) * (la * sin(theta2) + lc * sin(theta2 + theta3)), -cos(theta1) * lc * sin(theta2 + theta3);
%     cos(theta1) * (la * cos(theta2) + lc * cos(theta2 + theta3)), -cos(theta1) * (la * sin(theta2) + lc * sin(theta2 + theta3)), -cos(theta1) * lc * sin(theta2 + theta3);
%     la * cos(theta1) + lc * cos(theta2 + theta3), lc * cos(theta2 + theta3), lc * cos(theta2 + theta3);
% ];
% J_inv = inv(J);

% plot(xed,yed)